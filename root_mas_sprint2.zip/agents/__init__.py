"""Agents package.

This package contains classes for custom agents used in the Root‑MAS platform.
"""
