"""Coordination agent for managing task queues and scheduled operations.

This agent oversees task status, dispatches tasks at the right time and
coordinates work between other agents.  A minimal in‑memory queue is used
here as a placeholder for a real message broker such as Redis.  Scheduling
is implemented via Python's `sched` module for demonstration purposes; in a
production deployment you may wish to use Redis TTLs, cron jobs or
libraries like APScheduler.
"""

from __future__ import annotations

import logging
import sched
import time
from dataclasses import dataclass, field
from threading import Thread
from typing import Any, Callable, List, Optional

from autogen.agentchat import ConversableAgent

logger = logging.getLogger(__name__)


@dataclass
class CoordinationAgent(ConversableAgent):
    """Agent that manages a queue of tasks and periodic actions."""

    task_queue: List[Any] = field(default_factory=list)
    scheduler: sched.scheduler = field(default_factory=lambda: sched.scheduler(time.time, time.sleep))

    def __post_init__(self) -> None:
        # Call the ConversableAgent constructor explicitly; we assume a cheap model
        super().__init__(name=self.name, llm_config={"model": "openrouter/nous-hermes-2-mixtral-8x7b"})
        # Start the scheduler in a background thread
        t = Thread(target=self._run_scheduler, daemon=True)
        t.start()

    def _run_scheduler(self) -> None:
        """Run the scheduler loop in a separate thread."""
        logger.info("Coordination scheduler started")
        while True:
            self.scheduler.run(blocking=False)
            time.sleep(1)

    def schedule_task(self, delay: int, func: Callable, *args: Any, **kwargs: Any) -> None:
        """Schedule a function to be executed after `delay` seconds."""
        logger.debug("Scheduling task %s to run in %d seconds", func.__name__, delay)
        self.scheduler.enter(delay, 1, func, argument=args, kwargs=kwargs)

    def add_task(self, task: Any) -> None:
        """Add a task to the internal queue."""
        logger.debug("Adding task to queue: %s", task)
        self.task_queue.append(task)

    def dispatch_next_task(self) -> Optional[Any]:
        """Retrieve and remove the next task from the queue."""
        if self.task_queue:
            task = self.task_queue.pop(0)
            logger.debug("Dispatching task: %s", task)
            return task
        return None